import './App.css';
import { Aboutus } from './Components/Aboutus';
import {Footer} from './Components/Footer';
import { Home } from './Components/Home';
import Login from './Components/Login';
import Loginsignup from './Components/Loginsignup';
import { Navbar } from './Components/Navbar';
import {BrowserRouter,Route,Routes } from 'react-router-dom';
import {Doclogin} from './Components/Doctor/Doclogin';
import {Adlogin} from './Components/Admin/Adlogin';
import Docsignup from './Components/Doctor/Docsignup';

function App() 
{
  return (
    <div>
      <BrowserRouter>
   <Navbar/>
   <Routes>

    <Route path='/' element={<Home/>}/>
        <Route path='/signup' element={<Loginsignup/>}/>
        <Route path='/signin' element={<Login/>}/>
        <Route path='/doclogin' element={<Doclogin/>}/>
        <Route path='/adlogin' element={<Adlogin/>}/>
        <Route path='/docsignup' element={<Docsignup/>}/>
        <Route path='/about' element={<Aboutus/>} />
   </Routes>
   <Footer/>
   </BrowserRouter>
   </div>
  );
}

export default App;
