import React from 'react'
import './Aboutus.css';

export const Aboutus = () => {
  return (
    <div>Aboutus</div>
  )
}
