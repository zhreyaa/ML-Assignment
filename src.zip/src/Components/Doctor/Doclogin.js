import React from 'react';
import './Doclogin.css';
import { Link } from 'react-router-dom';

export const Doclogin = () => {
    return (
        <div className="login">
            <div className="login-container">
                <h1>Doctor Sign In</h1>
                <div className="login-fields">
                    <input type="email" placeholder='Email Address' />
                    <input type="password" placeholder='Password' />
                </div>
                <button>Sign In</button>
                <p className="login-signup">Don't have an account? <Link to='/docsignup'><span>Sign Up here</span></Link></p>  
            </div>
        </div>
    );
}

export default Doclogin;
