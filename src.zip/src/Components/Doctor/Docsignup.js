import React from 'react'
import './Docsignup.css'
import { Link } from 'react-router-dom'
export const Docsignup = () => {
    return (
    <div className="login">
     <div className="login-container">
        <h1>Doctor Sign Up</h1>
        <div className="login-fields">
            <input type="text" placeholder='Your Name' />
            <input type="email" placeholder='Email Address' />
            <input type="password" placeholder='Password' />
            </div>
          <button>Continue</button>
          <p className="login-login">Already have an account? <Link to='/doclogin'><span>Login here</span></Link></p>  
          <div className="login-agree">
            <input type="checkbox" name="" id="" />
            <p>By continuing, I agree to the terms of use & privacy policy.</p>
          </div>
     </div>
    </div>
    )
}

export default Docsignup