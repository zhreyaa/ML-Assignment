import React from 'react'
import './Footer.css'

export const Footer = () => {
    return (
    <div className="footer">
     <div className="footer-logo">
       HEALOFY
     </div>
     <ul className="footer-links">
        <li>Instagram</li>
        <li>Whatsapp</li>
        <li>Twitter</li>
        <li>Contact Us</li>
     </ul>
     <div className="footer-copyright">
        <hr/>
        <p>Copyright @ 2024 - All Rights Reserved.</p>
     </div>
    </div>
    )
}

export default Footer