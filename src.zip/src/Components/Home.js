export const Home = () => {
    return (
      <div className='home'>
        <div className="top-row">
          <img src="https://www.space2bheard.org/wp-content/uploads/sites/29/2022/01/Space2BHeard-Self-Help-Resources.jpg"/>        </div>
        <div className="bottom-row">
          <img src="https://a.storyblok.com/f/181188/1254x836/d04974895b/headway-best-self-improvement-apps-cover-image.jpg" />
          <img src="https://t3.ftcdn.net/jpg/04/61/46/70/360_F_461467085_HMS2c7U5iI0TF8o0aIBfzR4RvlPhcKTz.jpg"/>
          </div>
      </div>
    );
  };
  