import React from 'react';
import './Login.css';
import { Link } from 'react-router-dom';

const Login = () => {
    return (
        <div className="login">
            <div className="login-container">
                <h1>Sign In</h1>
                <div className="login-fields">
                    <input type="email" placeholder='Email Address' />
                    <input type="password" placeholder='Password' />
                </div>
                <button>Sign In</button>
                <p className="login-signup">Don't have an account? <Link to='/signup'><span>Sign Up here</span></Link></p>  
            </div>
            <div className='doctor-container'>
                <div className='doctor'>
                    <p className='doctor-signin'>Login as Doctor?<Link to='/doclogin'><span>Login in here</span></Link></p>
                    <p className='doctor-signin'>Login as Admin?<Link to='/adlogin'><span>Login in here</span></Link></p>
                </div>
            </div>
        </div>
    );
}

export default Login;
