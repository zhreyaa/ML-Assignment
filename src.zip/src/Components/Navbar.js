import React, { useState } from 'react';
import './Navbar.css';
import { Link } from 'react-router-dom';

export const Navbar = () => {
    return (
            <nav className='navbar'>
            <div className='navbar-container'>
                <Link to='/' className='navbar-logo'>
                    HEALOFY
                </Link>
                <div className='navbar-links'>
                    <Link to="/" className='navbar-link'>Home</Link>
                    <Link to="/about" className='navbar-link'>About Us</Link>
                </div>
                <div className='navbar-buttons'>
                   <Link to="/signin" ><button className='navbar-button'>Sign In</button></Link>
                    <Link to="/signup"><button className='navbar-button'>Sign Up</button></Link>
                </div>
            </div>
        </nav>
    );
};

export default Navbar;
